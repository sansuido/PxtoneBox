local	ActionInterval = import(".ActionInterval")

local	DelayTime = {}
DelayTime = class("cc.DelayTime", ActionInterval)

return DelayTime
