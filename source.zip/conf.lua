
function love.conf(t)
	t.version = "11.1"
	t.title = "PxtoneBox 0.3.3"
	t.window.icon = "PxtoneBox/res/favicon.png"
	t.window.width = 320 * 1
	t.window.height = 128 * 1
end
