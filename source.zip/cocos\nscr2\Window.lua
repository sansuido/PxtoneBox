local	Window = {}

Window.setTitle = function(title)
	gui.caption(title)
end

return Window
